package com.obo.jsloader;

import android.app.Application;
import android.test.ApplicationTestCase;

import org.xmlpull.v1.XmlPullParserException;

import java.util.List;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */
public class ApplicationTest extends ApplicationTestCase<Application> {

    public ApplicationTest() {
        super(Application.class);



    }



//    public static void main(String[] args) {
//
//        System.out.print("123");
//
////
////        List<String> list= null;
////
////        try {
////            list = new PullParseXml().PullParseXML();
////        } catch (XmlPullParserException e) {
////            e.printStackTrace();
////        }
//
//    }
}